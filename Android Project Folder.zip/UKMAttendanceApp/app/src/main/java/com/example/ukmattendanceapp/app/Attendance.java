package com.example.ukmattendanceapp.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;

import com.example.ukmattendanceapp.R;
import com.example.ukmattendanceapp.ScanTime;

import java.util.ArrayList;
import java.util.List;

public class Attendance extends AppCompatActivity {
    Bundle bundle;
    String matrix, password;
    Button btn_scan;
    ImageView iv_back;

    ListView lv_history;
    List<ScanTime> scanTimeList;
    ArrayAdapter<String> scanListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);

        bundle = getIntent().getExtras();
        matrix = bundle.getString("Matrix");
        password = bundle.getString("Password");

        btn_scan = findViewById(R.id.btn_scan_attendance);
        lv_history = findViewById(R.id.lv_history_attendance);
        iv_back = findViewById(R.id.iv_back_attendance);

        scanListAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        lv_history.setAdapter(scanListAdapter);
        scanTimeList = new ArrayList<>();
        btn_scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Attendance.this, AttendanceScan.class);
                bundle = new Bundle();
                bundle.putString("Matrix", matrix);
                bundle.putString("Password", password);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Attendance.this, HomePage.class);
                bundle = new Bundle();
                bundle.putString("Matrix", matrix);
                bundle.putString("Password", password);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }

    public void addScanTime(String time) {
        // 将扫码时间添加到列表
        ScanTime scanTime = new ScanTime(time);
        scanTimeList.add(scanTime);

        // 通知适配器数据已更改
        scanListAdapter.notifyDataSetChanged();
    }
}