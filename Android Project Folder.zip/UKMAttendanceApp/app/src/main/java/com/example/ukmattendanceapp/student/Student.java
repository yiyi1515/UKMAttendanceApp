package com.example.ukmattendanceapp.student;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;
@Entity
public class Student {
    @NonNull @PrimaryKey @ColumnInfo(name = "matrix")
    private String matrix;
    @NonNull@ColumnInfo(name = "uesrname")
    private String name;
    @NonNull@ColumnInfo(name = "password")
    private String password;
    @NonNull@ColumnInfo(name = "email")
    private String email;
    @NonNull@ColumnInfo(name = "birthday")
    private String birthday;
    @NonNull@ColumnInfo(name = "actual")
    private String actualAttendanceCount; // 实际出勤次数
    @NonNull@ColumnInfo(name = "ex")
    private String expectedAttendanceCount; // 应出勤次数
    private String attendanceRate; // 出勤率

    // 构造方法
    public Student(String matrix, @NonNull String name, @NonNull String password, @NonNull String email, @NonNull String birthday) {
        this.matrix = matrix;
        this.name = name;
        this.password = password;
        this.email = email;
        this.birthday = birthday;
        this.actualAttendanceCount = "0"; // 初始化为0
        this.expectedAttendanceCount = "0"; // 初始化为0
        this.attendanceRate = calculateAttendanceRate(); // 使用calculateAttendanceRate()计算初始值
    }
    @Ignore
    public Student(String matrix){
        this.matrix = matrix;
    }

    // Getter 和 Setter 方法

    public String getMatrix() {
        return matrix;
    }

    public void setMatrix(String matrix) {
        this.matrix = matrix;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @NonNull
    public String getPassword() {
        return password;
    }

    public void setPassword(@NonNull String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getAttendanceRate() {
        return attendanceRate;
    }

    public void setAttendanceRate(String attendanceRate) {
        this.attendanceRate = attendanceRate;
    }
    public String getActualAttendanceCount() {
        return actualAttendanceCount;
    }

    public void setActualAttendanceCount(String actualAttendanceCount) {
        this.actualAttendanceCount = actualAttendanceCount;
    }

    public String getExpectedAttendanceCount() {
        return expectedAttendanceCount;
    }

    public void setExpectedAttendanceCount(String expectedAttendanceCount) {
        this.expectedAttendanceCount = expectedAttendanceCount;
    }

    // 计算出勤率的方法
    public String calculateAttendanceRate() {
        if (Float.parseFloat(expectedAttendanceCount) > 0) {
            return String.valueOf((Float.parseFloat(actualAttendanceCount) / Float.parseFloat(expectedAttendanceCount)) * 100);
        } else {
            return String.valueOf(0.0f); // 避免除以零的情况
        }
    }
}

