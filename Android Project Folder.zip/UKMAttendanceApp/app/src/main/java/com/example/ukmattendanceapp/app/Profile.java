package com.example.ukmattendanceapp.app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.ukmattendanceapp.R;
import com.example.ukmattendanceapp.database.DBHelper;
import com.example.ukmattendanceapp.student.Student;

public class Profile extends AppCompatActivity {

    Bundle bundle;
    Student student;
    String matrix, password;
    TextView tv_name, tv_matrix;
    ImageView iv_back;
    EditText et_email, et_name, et_password, et_date;
    private boolean isVisible = false;
    private Handler handler = new Handler(Looper.getMainLooper());
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        // 获取数据库对象
        DBHelper dbHelper = new DBHelper(Profile.this);

        bundle = getIntent().getExtras();
        matrix = bundle.getString("Matrix");
        password = bundle.getString("Password");

        tv_name = findViewById(R.id.tv_name_profile);
        tv_matrix = findViewById(R.id.tv_matrix_profile);
        et_email = findViewById(R.id.et_email_profile);
        et_name = findViewById(R.id.et_name_profile);
        et_password = findViewById(R.id.et_password_profile);
        et_date = findViewById(R.id.et_date_profile);
        iv_back = findViewById(R.id.iv_back_profile);

        new Thread(new Runnable() {
            @Override
            public void run() {
                // 在这里执行数据库操作
                student = dbHelper.getStudentByMatrix(matrix);

                // 使用 Handler 发送消息到主线程
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (student != null) {
                            // 更新 UI
                            tv_name.setText(student.getName());
                            tv_matrix.setText(student.getMatrix());
                            et_email.setText(student.getEmail());
                            et_name.setText(tv_name.getText().toString());
                            et_password.setText("******");
                            et_date.setText(student.getBirthday());
                        } else {
                            // 在这里处理对象未初始化的情况
                            Log.e("Profile", "Student object is null");
                        }
                    }
                });
            }
        }).start();

        et_password.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (!isVisible){
                    et_password.setText("******");
                }else {
                    //et_password.setText(CredentialsManager.getPassword(Profile.this));
                    et_password.setText(password);
                }
                isVisible = !isVisible;
                return false;
            }
        });
        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Profile.this, HomePage.class);
                bundle = new Bundle();
                bundle.putString("Matrix", matrix);
                bundle.putString("Password", password);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });


    }

}
