package com.example.ukmattendanceapp.database;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.ukmattendanceapp.student.Student;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "user_db";
    private static final String TABLE_NAME = "users";
    private static final String COL_MATRIX = "matrix";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";
    private static final String COL_EMAIL = "email";
    private static final String COL_BIRTHDAY = "birthday";
    private static final String COL_ACTUAL = "actual";
    private static final String COL_EX = "ex";
    public DBHelper(Context context){super(context,DATABASE_NAME,null,1);}
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + " ("
        + COL_MATRIX + " TEXT PRIMARY KEY, "
        + COL_USERNAME + " TEXT NOT NULL, "
        + COL_PASSWORD + " TEXT NOT NULL, "
        + COL_EMAIL + " TEXT NOT NULL, "
        + COL_BIRTHDAY + " TEXT NOT NULL, "
        + COL_ACTUAL + " TEXT NOT NULL, "
        + COL_EX + " TEXT NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean insertData(String matrix, String username, String password, String email, String birthday, String actual, String ex){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_MATRIX, matrix);
        contentValues.put(COL_USERNAME, username);
        contentValues.put(COL_PASSWORD, password);
        contentValues.put(COL_EMAIL, email);
        contentValues.put(COL_BIRTHDAY, birthday);
        contentValues.put(COL_ACTUAL, actual);
        contentValues.put(COL_EX, ex);
        long result = db.insert(TABLE_NAME, null, contentValues);
        return result != -1;
    }

    public boolean insertData(String matrix,String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_MATRIX, matrix);
        contentValues.put(COL_USERNAME, "username");
        contentValues.put(COL_PASSWORD, password);
        contentValues.put(COL_EMAIL, "email");
        contentValues.put(COL_BIRTHDAY, "birthday");
        contentValues.put(COL_ACTUAL, "5");
        contentValues.put(COL_EX, "10");
        long result = db.insert(TABLE_NAME, null, contentValues);
        return result != -1;
    }

    public boolean updateData(String matrix, String username, String password, String email, String birthday, String actual, String ex) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_MATRIX, matrix);
        contentValues.put(COL_USERNAME, username);
        contentValues.put(COL_PASSWORD, password);
        contentValues.put(COL_EMAIL, email);
        contentValues.put(COL_BIRTHDAY, birthday);
        contentValues.put(COL_ACTUAL, actual);
        contentValues.put(COL_EX, ex);
        // Specify the condition for updating (in this case, based on the matrix value)
        String whereClause = COL_MATRIX + "=?";
        String[] whereArgs = {matrix};
        // Perform the update
        int rowsAffected = db.update(TABLE_NAME, contentValues, whereClause, whereArgs);
        // Return true if at least one row was affected, indicating a successful update
        return rowsAffected > 0;
    }

    public boolean checkUser(String matrix, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE "
                + COL_MATRIX + "=? AND " + COL_PASSWORD + "=?", new String[]{matrix, password});
        return cursor.getCount() > 0;
    }

    /**
     * 查询学生信息
     * @return 学生对象，如果未找到则返回 null
     */
    @SuppressLint("Range")
    public Student getStudentByMatrix(String matrix) {
        SQLiteDatabase db = this.getReadableDatabase();
        Student student = null;

        /*Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME +
                        " WHERE " + COL_MATRIX + " = ? AND " + COL_PASSWORD + " = ?",
                new String[]{matrix, password});*/

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME +
                        " WHERE " + COL_MATRIX + " = ?",
                new String[]{matrix});


        if (cursor.moveToFirst()) {
            student = new Student(matrix);
            student.setMatrix(cursor.getString(cursor.getColumnIndex(COL_MATRIX)));
            student.setName(cursor.getString(cursor.getColumnIndex(COL_USERNAME)));
            student.setPassword(cursor.getString(cursor.getColumnIndex(COL_PASSWORD)));
            student.setEmail(cursor.getString(cursor.getColumnIndex(COL_EMAIL)));
            student.setBirthday(cursor.getString(cursor.getColumnIndex(COL_BIRTHDAY)));
            student.setActualAttendanceCount(String.valueOf(cursor.getColumnIndex(COL_ACTUAL)));
            student.setExpectedAttendanceCount(String.valueOf(cursor.getColumnIndex(COL_EX)));

        }

        cursor.close();
        return student;
    }

    @SuppressLint("Range")
    public List<Student> getAllStudents() {
            List<Student> studentList = new ArrayList<>();
            SQLiteDatabase db = this.getReadableDatabase();

            String[] projection = {
                    COL_MATRIX,
                    COL_USERNAME,
                    COL_PASSWORD,
                    COL_EMAIL,
                    COL_BIRTHDAY,
                    COL_ACTUAL,
                    COL_EX
            };

            Cursor cursor = db.query(
                    TABLE_NAME,         // 表名
                    projection,         // 查询的列
                    null,               // WHERE 子句
                    null,               // WHERE 子句的参数
                    null,               // GROUP BY
                    null,               // HAVING
                    null                // ORDER BY
            );

            if (cursor != null && cursor.moveToFirst()) {
                do {
                    // 从 Cursor 中获取学生数据并创建 Student 对象
                    String matrix = cursor.getString(cursor.getColumnIndex(COL_MATRIX));
                    String username = cursor.getString(cursor.getColumnIndex(COL_USERNAME));
                    String password = cursor.getString(cursor.getColumnIndex(COL_PASSWORD));
                    String email = cursor.getString(cursor.getColumnIndex(COL_EMAIL));
                    String birthday = cursor.getString(cursor.getColumnIndex(COL_BIRTHDAY));
                    int actualAttendance = cursor.getInt(cursor.getColumnIndex(COL_ACTUAL));
                    int expectedAttendance = cursor.getInt(cursor.getColumnIndex(COL_EX));

                    // 创建 Student 对象并添加到列表
                    Student student = new Student(matrix, username, password, email, birthday);
                    student.setActualAttendanceCount(String.valueOf(actualAttendance));
                    student.setExpectedAttendanceCount(String.valueOf(expectedAttendance));

                    studentList.add(student);
                } while (cursor.moveToNext());

                // 关闭 Cursor
                cursor.close();
            }

            // 关闭数据库连接
            db.close();

            return studentList;
        }

    public boolean deleteStudent(String matrix) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, COL_MATRIX + "=?", new String[]{matrix}) > 0;
    }

}
