package com.example.ukmattendanceapp.app;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.example.ukmattendanceapp.R;
import com.google.zxing.ResultPoint;
import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.BarcodeResult;
import com.journeyapps.barcodescanner.CompoundBarcodeView;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AttendanceScan extends AppCompatActivity {
    private static final int CAMERA_PERMISSION_REQUEST = 100;
    Bundle bundle;
    String matrix, password;
    ImageView iv_back, iv_scan;
    private CompoundBarcodeView barcodeView;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance_scan);

        bundle = getIntent().getExtras();
        matrix = bundle.getString("Matrix");
        password = bundle.getString("Password");

        iv_back = findViewById(R.id.iv_back_scan);
        iv_scan = findViewById(R.id.iv_scan_scan);

        // 检查并请求相机权限
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST);
        } else {
            // 相机权限已授予，初始化并使用相机
            barcodeView = findViewById(R.id.barcodeView);

            barcodeView.decodeContinuous(callback);
        }

        barcodeView.setVisibility(View.GONE);

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AttendanceScan.this, Attendance.class);
                bundle = new Bundle();
                bundle.putString("Matrix", matrix);
                bundle.putString("Password", password);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

        iv_scan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (barcodeView.getVisibility() == View.VISIBLE) {
                    // 如果 barcodeView 当前可见，就隐藏它
                    barcodeView.setVisibility(View.GONE);
                } else {
                    // 如果 barcodeView 当前不可见，就显示它
                    barcodeView.setVisibility(View.VISIBLE);
                    showTestAlertDialog();
                }
            }
        });
    }

    private BarcodeCallback callback = new BarcodeCallback() {
        @Override
        public void barcodeResult(BarcodeResult result) {
            if (result.getText() != null) {
                // 扫描成功，处理扫描结果
                handleScanResult(result.getText());
                // 添加扫码时间到Attendance类的ListView
                addScanTimeToAttendance(result.getText());
            }
        }

        @Override
        public void possibleResultPoints(List<ResultPoint> resultPoints) {

        }

    };

    private void addScanTimeToAttendance(String result) {
        // 获取当前时间
        String currentTime = getCurrentTime();

        // 将扫码时间添加到Attendance类的ListView
        ((Attendance) getParent()).addScanTime(currentTime);
    }

    private String getCurrentTime() {
        // 获取当前时间的代码，可以使用 SimpleDateFormat 等方式
        // 这里简化为直接返回当前时间的字符串
        return new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
    }

    private void handleScanResult(String result) {
        // 在这里处理扫描结果，可以是打开新的Activity，也可以是其他操作
        Log.d("ScanResult", result);
    }

    @Override
    protected void onResume() {
        super.onResume();
        barcodeView.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        barcodeView.pause();
    }

    private void showTestAlertDialog() {
        // 构建AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Tip")
                .setMessage("Just For Test")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // 点击确定按钮的处理
                        dialog.dismiss();
                    }
                });

        // 显示AlertDialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}