package com.example.ukmattendanceapp.app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.ukmattendanceapp.R;
import com.example.ukmattendanceapp.student.Student;

public class Setting extends AppCompatActivity {
    Bundle bundle;
    String matrix, password;
    Student student;
    ImageView img_myaccount, img_manageuser, img_privacy, img_contactus, img_back;
    TextView tv_myaccount, tv_manageuser, tv_privacy, tv_contactus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        bundle = getIntent().getExtras();
        matrix = bundle.getString("Matrix");
        password = bundle.getString("Password");

        img_myaccount = findViewById(R.id.iv_myaccount_setting);
        img_manageuser = findViewById(R.id.iv_manageuser_setting);
        img_privacy = findViewById(R.id.iv_privacy_setting);
        img_contactus = findViewById(R.id.iv_contactus_setting);
        tv_myaccount = findViewById(R.id.tv_myaccount_setting);
        tv_manageuser = findViewById(R.id.tv_manageuser_setting);
        tv_privacy = findViewById(R.id.tv_privacy_setting);
        tv_contactus = findViewById(R.id.tv_contactus_setting);
        img_back = findViewById(R.id.iv_back_setting);

        img_manageuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                manageuserAction();
            }
        });
        tv_manageuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                manageuserAction();
            }
        });
        img_privacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                privacyAction();
            }
        });
        tv_privacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                privacyAction();
            }
        });
        img_contactus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contactusAction();
            }
        });
        tv_contactus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                contactusAction();
            }
        });
        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Setting.this, HomePage.class);
                bundle = new Bundle();
                bundle.putString("Matrix", matrix);
                bundle.putString("Password", password);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }

    private void manageuserAction(){
        Intent intent = new Intent(Setting.this, AddUser.class);
        bundle = new Bundle();
        bundle.putString("Matrix",matrix);
        bundle.putString("Password",password);
        intent.putExtras(bundle);
        startActivity(intent);
    }
    private void privacyAction(){
        AlertDialog.Builder builder = new AlertDialog.Builder(Setting.this);
        builder.setTitle("Privacy Policy and Terms")
                .setMessage("Here is a brief summary of our privacy policy.\nClick on the link below to view the full Privacy Policy and Terms.")
                .setPositiveButton("View details", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // 在这里打开详细隐私政策页面
                        Intent intent = new Intent(Setting.this, PrivacyPolicy.class);
                        startActivity(intent);
                    }
                })
                .setNegativeButton("Close", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // 用户选择关闭
                    }
                })
                .show();
    }
    private void contactusAction() {
        final CharSequence[] options = {"Phone", "Email", "Website"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select contact information");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case 0: // 电话
                        dialPhoneNumber("tel:+0146111527"); // 替换成你的电话号码
                        break;
                    case 1: // 邮箱
                        sendEmail("A191305@siswa.ukm.edu.my"); // 替换成你的邮箱地址
                        break;
                    case 2: // 网站
                        openWebsite("https://smplucee.ukm.my/"); // 替换成你的网站地址
                        break;
                }
            }
        });

        builder.show();
    }

    private void dialPhoneNumber(String phoneNumber) {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse(phoneNumber));
        startActivity(intent);
    }
    private void sendEmail(String emailAddress) {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:" + emailAddress));
        startActivity(intent);
    }
    private void openWebsite(String url) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }
}