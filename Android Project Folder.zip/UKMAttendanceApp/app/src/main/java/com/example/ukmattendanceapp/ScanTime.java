package com.example.ukmattendanceapp;

public class ScanTime {

    private String time; // 扫码时间
    private String matrix;

    public ScanTime(String time) {
        this.time = time;
    }
    public ScanTime(String time, String matrix){
        this.time = time;
        this.matrix = matrix;
    }

    public String getTime() {
        return time;
    }

    public String getMatrix() {
        return matrix;
    }

    public void setMatrix(String matrix) {
        this.matrix = matrix;
    }
}
