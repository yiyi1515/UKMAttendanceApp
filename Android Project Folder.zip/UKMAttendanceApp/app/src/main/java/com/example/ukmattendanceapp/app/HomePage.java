package com.example.ukmattendanceapp.app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.ukmattendanceapp.R;
import com.example.ukmattendanceapp.database.DBHelper;
import com.example.ukmattendanceapp.student.Student;
public class HomePage extends AppCompatActivity {

    ImageView img_calendar, img_profile, img_setting, img_logout;
    Bundle bundle;
    String matrix, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        bundle = getIntent().getExtras();
        matrix = bundle.getString("Matrix");
        password = bundle.getString("Password");

        img_calendar = findViewById(R.id.img_calendar_homepage);
        img_profile = findViewById(R.id.img_profile_homepage);
        img_setting = findViewById(R.id.img_setting_homepage);
        img_logout = findViewById(R.id.img_logout_homepage);

        img_calendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePage.this, Attendance.class);
                bundle = new Bundle();
                bundle.putString("Matrix", matrix);
                bundle.putString("Password", password);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        img_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePage.this, Profile.class);
                bundle = new Bundle();
                bundle.putString("Matrix", matrix);
                bundle.putString("Password", password);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        img_setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePage.this, Setting.class);
                bundle = new Bundle();
                bundle.putString("Matrix", matrix);
                bundle.putString("Password", password);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        img_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showLogoutConfirmationDialog();
            }
        });

    }
    private void showLogoutConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(HomePage.this);
        builder.setTitle("Logout Confirmation")
                .setMessage("Are you sure you want to logout?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // 用户点击了确认退出
                        // 在这里执行退出操作
                        Intent intent = new Intent(HomePage.this, Login.class);
                        startActivity(intent);
                        finish(); // 退出当前 Activity，可以根据实际需求修改
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // 用户点击了取消退出
                        dialog.dismiss(); // 关闭对话框
                    }
                })
                .show();
    }
}