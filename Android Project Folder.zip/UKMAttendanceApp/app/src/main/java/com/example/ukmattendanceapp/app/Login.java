package com.example.ukmattendanceapp.app;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.ukmattendanceapp.R;
import com.example.ukmattendanceapp.database.DBHelper;

public class Login extends AppCompatActivity {
    String matrix, password;
    Button btn_login;
    EditText et_matrix, et_password;
    TextView tv_ukm;
    ImageView iv_ukm;
    Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btn_login = findViewById(R.id.btn_login_login);
        et_matrix = findViewById(R.id.et_matrix_login);
        et_password = findViewById(R.id.et_password_login);
        tv_ukm = findViewById(R.id.tv_ukm_login);
        iv_ukm = findViewById(R.id.img_ukm_login);

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (editTextIsEmpty()){
                    return;
                }
                // 获取用户输入的学号和密码
                matrix = et_matrix.getText().toString();
                password = et_password.getText().toString();

                DBHelper dbHelper = new DBHelper(Login.this);

                // 检查学生信息和密码是否匹配
                if (dbHelper.checkUser(matrix, password)) {
                    showAlertDialog("", "Login successful");
                    Intent intent = new Intent(Login.this, HomePage.class);
                    bundle = new Bundle();
                    bundle.putString("Matrix",matrix);
                    bundle.putString("Password",password);
                    intent.putExtras(bundle);
                    startActivity(intent);
                } else {
                    showAlertDialog("Error","Login failed");
                }
            }
        });

        tv_ukm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_matrix.setText("A123456");
                et_password.setText("123456");
            }
        });

        iv_ukm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DBHelper dbHelper = new DBHelper(Login.this);
                dbHelper.insertData(matrix, password);
                showAlertDialog("Inserted Succeed",matrix + " " + password);
            }
        });
    }

    private boolean editTextIsEmpty() {
        if (TextUtils.isEmpty(et_matrix.getText().toString())) {
            et_matrix.setError("Cannot be Empty");
        }
        if (TextUtils.isEmpty(et_password.getText().toString())) {
            et_matrix.setError("Cannot be Empty");
        }
        if (TextUtils.isEmpty(et_matrix.getText().toString()) || TextUtils.isEmpty(et_password.getText().toString())) {
            return true;
        }
        else return false;
    }

    private void showAlertDialog(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title).setMessage(message).show();
    }

}