package com.example.ukmattendanceapp.app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.ukmattendanceapp.R;

public class PrivacyPolicy extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_privacy_policy);
    }
}