package com.example.ukmattendanceapp.app;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ukmattendanceapp.R;
import com.example.ukmattendanceapp.database.DBHelper;
import com.example.ukmattendanceapp.student.Student;

import java.util.ArrayList;
import java.util.List;

public class AddUser extends AppCompatActivity {
    Bundle bundle;
    String matrix, password;
    ImageView iv_back;
    EditText et_matrix, et_name, et_password, et_email, et_date, et_act, et_ex;
    TextView tv_rate;
    ListView lv_users;
    Button btn_add, btn_update;
    ArrayAdapter<String> userListAdapter;
    ArrayList<String> userArray;
    ArrayList<String> userID;
    DBHelper dbHelper = new DBHelper(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);

        bundle = getIntent().getExtras();
        matrix = bundle.getString("Matrix");
        password = bundle.getString("Password");

        et_matrix = findViewById(R.id.et_matrix_adduser);
        et_name = findViewById(R.id.et_name_adduser);
        et_password = findViewById(R.id.et_password_adduser);
        et_email = findViewById(R.id.et_email_adduser);
        et_date = findViewById(R.id.et_date_adduser);
        et_act = findViewById(R.id.et_act_adduser);
        et_ex = findViewById(R.id.et_ex_adduser);
        tv_rate = findViewById(R.id.tv_rate_adduser);
        btn_add = findViewById(R.id.btn_add_adduser);
        btn_update = findViewById(R.id.btn_update_adduser);
        lv_users = findViewById(R.id.lv_user_adduser);
        iv_back = findViewById(R.id.iv_back_adduser);

        userListAdapter = new ArrayAdapter<>(AddUser.this,
                android.R.layout.simple_list_item_1);
        userArray = new ArrayList<String>();
        userID = new ArrayList<String>();


        getAllUser();

        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editTextIsEmpty())
                    return;
                if (!isNum(et_act.getText().toString())||!isNum(et_ex.getText().toString())){
                    android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(AddUser.this);
                    builder.setTitle("Error").setMessage("ActualAttendanceCount and expectedAttendanceCount must be Number.").show();
                    return;
                }
                saveUser();
            }
        });

        btn_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editTextIsEmpty()){
                    return;
                }
                if (!isNum(et_act.getText().toString())||!isNum(et_ex.getText().toString())){
                    android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(AddUser.this);
                    builder.setTitle("Error").setMessage("ActualAttendanceCount and expectedAttendanceCount must be Number.").show();
                    return;
                }
                updateUser();
            }
        });

        lv_users.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        final Student selected = dbHelper.getStudentByMatrix(userID.get(position));

                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                et_matrix.setText(selected.getMatrix());
                                et_name.setText(selected.getName());
                                et_email.setText(selected.getEmail());
                                et_date.setText(selected.getBirthday());
                                et_act.setText(selected.getActualAttendanceCount());
                                et_ex.setText(selected.getExpectedAttendanceCount());
                                tv_rate.setText(selected.calculateAttendanceRate());
                            }
                        });
                    }
                }).start();
            }
        });

        lv_users.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(AddUser.this);
                alertDialogBuilder.setTitle("Remove User");
                alertDialogBuilder.setMessage("Are you sure you want to remove the user: "
                        +userID.get(position));
                alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        toast(getApplicationContext(),"Action Canceled");
                    }
                });

                alertDialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Student student = new Student(userID.get(position).toString());
                        deleteUser(student);
                    }
                });

                alertDialogBuilder.show();

                return true;
            }
        });

        iv_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddUser.this, Setting.class);
                bundle = new Bundle();
                bundle.putString("Matrix", matrix);
                bundle.putString("Password", password);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }

    public boolean isNum(String string){
        try {
            // 尝试将字符串转换为整数
            Float.parseFloat(string);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    public void saveUser(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                Student search = dbHelper.getStudentByMatrix(et_matrix.getText().toString());
                if (search!= null){
                    toast(getApplicationContext(),"Student Exist");
                    return;
                }
                Student student = new Student(
                        et_matrix.getText().toString(),
                        et_name.getText().toString(),
                        et_password.getText().toString(),
                        et_email.getText().toString(),
                        et_date.getText().toString());
                student.setActualAttendanceCount(et_act.getText().toString());
                student.setExpectedAttendanceCount(et_ex.getText().toString());
                student.setAttendanceRate(student.calculateAttendanceRate());

                dbHelper.insertData(student.getMatrix(), student.getName(), student.getPassword(), student.getEmail(),
                        student.getBirthday(), student.getActualAttendanceCount(), student.getExpectedAttendanceCount());
                toast(getApplicationContext(),"Student Added");
                getAllUser();
            }
        }).start();
    }
    public void updateUser(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                Student student = new Student(
                        et_matrix.getText().toString(),
                        et_name.getText().toString(),
                        et_password.getText().toString(),
                        et_email.getText().toString(),
                        et_date.getText().toString());
                student.setActualAttendanceCount(et_act.getText().toString());
                student.setExpectedAttendanceCount(et_ex.getText().toString());
                student.setAttendanceRate(student.calculateAttendanceRate());

                dbHelper.updateData(student.getMatrix(), student.getName(), student.getPassword(), student.getEmail(),
                        student.getBirthday(), student.getActualAttendanceCount(), student.getExpectedAttendanceCount());
                toast(getApplicationContext(),"Student Added");
                getAllUser();
            }
        }).start();
    }
    public void deleteUser(final Student student){
        new Thread(new Runnable() {
            @Override
            public void run() {
                dbHelper.deleteStudent(student.getMatrix());
                toast(getApplicationContext(),"Student Removed");
                getAllUser();
            }
        }).start();
    }
    public void getAllUser(){
        userID.clear();
        userArray.clear();
        new Thread(new Runnable() {
            @Override
            public void run() {
                List<Student> students = dbHelper.getAllStudents();
                String studentInfor;
                for (Student student: students){
                    studentInfor = student.getMatrix() + " " + student.getName()
                            +"\n" + student.getPassword()
                            + "\n" + student.getEmail() + " " + student.getBirthday()
                            +"\n" + student.getActualAttendanceCount() + " " + student.getExpectedAttendanceCount()
                            +" " + student.calculateAttendanceRate();
                    userArray.add(studentInfor);
                    userID.add(student.getMatrix());
                }
                showDataInListView();
            }
        }).start();
    }
    public void showDataInListView(){
        AddUser.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                userListAdapter.clear();
                userListAdapter.addAll(userArray);
                lv_users.setAdapter(userListAdapter);
            }
        });
    }
    private boolean editTextIsEmpty(){
        if (TextUtils.isEmpty(et_matrix.getText().toString())){
            et_matrix.setError("Cannot be Empty");
            return true;
        }
        if (TextUtils.isEmpty(et_name.getText().toString())){
            et_name.setError("Cannot be Empty");
            return true;
        }
        if (TextUtils.isEmpty(et_password.getText().toString())){
            et_password.setError("Cannot be Empty");
            return true;
        }
        if (TextUtils.isEmpty(et_email.getText().toString())){
            et_email.setError("Cannot be Empty");
            return true;
        }
        if (TextUtils.isEmpty(et_date.getText().toString())){
            et_date.setError("Cannot be Empty");
            return true;
        }
        if (TextUtils.isEmpty(et_act.getText().toString())){
            et_act.setError("Cannot be Empty");
            return true;
        }
        if (TextUtils.isEmpty(et_ex.getText().toString())){
            et_ex.setError("Cannot be Empty");
            return true;
        }
        else return false;
    }
    public void toast(final Context context, final String text){
        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(context,text,Toast.LENGTH_SHORT).show();
            }
        });
    }

}